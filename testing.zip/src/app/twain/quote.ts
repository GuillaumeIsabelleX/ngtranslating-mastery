export class Quote {
  id: number;
  quote: string;
}
